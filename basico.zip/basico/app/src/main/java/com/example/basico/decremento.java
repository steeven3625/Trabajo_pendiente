package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class decremento extends AppCompatActivity {
    TextView res_decremento;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decremento);
        res_decremento=findViewById(R.id.res_decremento);
        int resultado =getIntent().getIntExtra("resul",0);

        res_decremento.setText(resultado + " ");
    }
    public void regresar5(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}