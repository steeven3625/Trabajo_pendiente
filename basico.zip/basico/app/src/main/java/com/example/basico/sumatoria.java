package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class sumatoria extends AppCompatActivity {
    TextView res_suma;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sumatoria);
        res_suma=findViewById(R.id.res_suma);

        int resultado =getIntent().getIntExtra("resul",0);

        res_suma.setText(resultado + " ");
    }
    public void regresar(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}