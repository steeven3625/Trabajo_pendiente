package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {
    EditText num1;
    EditText num2;
    EditText num3;
    Button operador_suma;
    Button operador_resta;
    Button operador_multi;
    Button operador_divi;
    Button operar_factorial;
    Button operar_fibo;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        num3 = findViewById(R.id.num3);
        operador_suma = findViewById(R.id.operador_suma);
        operador_resta = findViewById(R.id.operador_resta);
        operador_multi = findViewById(R.id.operador_multi);
        operador_divi = findViewById(R.id.operador_divi);
        operar_factorial = findViewById(R.id.operar_factorial);
        operar_fibo = findViewById(R.id.operar_fibo);

        operador_suma.setOnClickListener(new View.OnClickListener(){
    @Override
    public void onClick(View view){
        int number1 = Integer.parseInt(num1.getText().toString());
        int number2 = Integer.parseInt(num2.getText().toString());

        int result = number1 + number2;

        Intent i = new Intent(MainActivity2.this,sumatoria.class);
        i.putExtra("resul",result);
        startActivity(i);
    }
});
        operador_resta.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int number1 = Integer.parseInt(num1.getText().toString());
                int number2 = Integer.parseInt(num2.getText().toString());

                int result = number1 - number2;

                Intent i = new Intent(MainActivity2.this,decremento.class);
                i.putExtra("resul",result);
                startActivity(i);
            }
        });
        operador_multi.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int number1 = Integer.parseInt(num1.getText().toString());
                int number2 = Integer.parseInt(num2.getText().toString());

                int result = number1 * number2;

                Intent i = new Intent(MainActivity2.this,multi.class);
                i.putExtra("resul",result);
                startActivity(i);
            }
        });
        operador_divi.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int number1 = Integer.parseInt(num1.getText().toString());
                int number2 = Integer.parseInt(num2.getText().toString());

                int result = number1 / number2;

                Intent i = new Intent(MainActivity2.this,divi.class);
                i.putExtra("resul",result);
                startActivity(i);
            }
        });
        operar_fibo.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int number = Integer.parseInt(num3.getText().toString());
                int result = fibonacci(number);
                Intent i = new Intent(MainActivity2.this,fibonacci1.class);
                i.putExtra("resul",result);
                startActivity(i);
            }
            public int fibonacci(int number) {
                if (number == 0 || number == 1) {
                    return number;
                } else {
                    return fibonacci(number - 1) + fibonacci(number - 2);
                }
            }
        });
        operar_factorial.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                int number1 = Integer.parseInt(num3.getText().toString());
                int result = factorial(number1);
                Intent i = new Intent(MainActivity2.this,factorial1.class);
                i.putExtra("resul",result);
                startActivity(i);
            }
            public int factorial(int number1){
                if(number1==0 || number1==1){
                    return 1;
                }else{
                    return number1 * factorial(number1-1);
                }
            }
        });

    }
    public void principal(View view){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
    public void pag_sumar(View view){
        Intent i = new Intent(this, solo_suma.class);
        startActivity(i);
    }
    public void pag_restar(View view){
        Intent i = new Intent(this, solo_resta.class);
        startActivity(i);
    }
    public void pag_multi(View view){
        Intent i = new Intent(this, solo_multi.class);
        startActivity(i);
    }
    public void pag_divi(View view){
        Intent i = new Intent(this, solo_divi.class);
        startActivity(i);
    }
    public void pag_fibo(View view){
        Intent i = new Intent(this, solo_fibo.class);
        startActivity(i);
    }
    public void pag_factorial(View view){
        Intent i = new Intent(this, solo_factorial.class);
        startActivity(i);
    }
}
