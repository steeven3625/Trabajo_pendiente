package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class solo_resta extends AppCompatActivity {
    private EditText resta1;
    private EditText resta2;
    Button calcu_resta;
    TextView resultados5;

    @SuppressLint("MissingInflatedId")

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solo_resta);
        resta1 = findViewById(R.id.resta1);
        resta2 = findViewById(R.id.resta2);
        calcu_resta = findViewById(R.id.calcu_resta);
        resultados5 = findViewById(R.id.resultados5);
        calcu_resta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int res = Integer.parseInt(resta1.getText().toString()) - Integer.parseInt(resta2.getText().toString());
                resultados5.setText(res + " ");
            }
        });
    }
    public void regresar12(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}