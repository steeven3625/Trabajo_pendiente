package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class solo_multi extends AppCompatActivity {
    private EditText multi1;
    private EditText multi2;
    Button calcu_multi;
    TextView resultados4;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solo_multi);
        multi1 = findViewById(R.id.multi1);
        multi2 = findViewById(R.id.multi2);
        calcu_multi = findViewById(R.id.calcu_multi);
        resultados4 = findViewById(R.id.resultados4);
        calcu_multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int res = Integer.parseInt(multi1.getText().toString()) * Integer.parseInt(multi2.getText().toString());
                resultados4.setText(res + " ");
            }
        });
    }
    public void regresar13(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}