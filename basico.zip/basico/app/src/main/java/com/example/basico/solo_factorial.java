package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class solo_factorial extends AppCompatActivity {
    private EditText factorial1;
    Button calcu_factorial;
    TextView resultados2;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solo_factorial);
        factorial1 = findViewById(R.id.factorial1);
        calcu_factorial = findViewById(R.id.calcu_factorial);
        resultados2 = findViewById(R.id.resultados2);
        calcu_factorial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int number1 = Integer.parseInt(factorial1.getText().toString());
                int res = factorial(number1);
                resultados2.setText(res + " ");
            }
            public int factorial(int number1){
                if(number1==0 || number1==1){
                    return 1;
                }else{
                    return number1 * factorial(number1-1);
                }
            }
        });
    }
    public void regresar15(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}