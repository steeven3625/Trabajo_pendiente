package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class divi extends AppCompatActivity {
TextView res_divi;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_divi);
        res_divi = findViewById(R.id.res_divi);
        int resultado =getIntent().getIntExtra("resul",0);

        res_divi.setText(resultado + " ");
    }
    public void regresar4(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}