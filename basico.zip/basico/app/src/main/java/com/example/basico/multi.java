package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class multi extends AppCompatActivity {
TextView res_multi;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multi);

        res_multi=findViewById(R.id.res_multi);

        int resultado =getIntent().getIntExtra("resul",0);

        res_multi.setText(resultado + " ");
    }
    public void regresar1(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}