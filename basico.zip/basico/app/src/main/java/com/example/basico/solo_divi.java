package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class solo_divi extends AppCompatActivity {
    private EditText divi1;
    private EditText divi2;
    Button calcu_divi;
    TextView resultados1;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solo_divi);
        divi1 = findViewById(R.id.divi1);
        divi2 = findViewById(R.id.divi2);
        calcu_divi = findViewById(R.id.calcu_divi);
        resultados1 = findViewById(R.id.resultados1);
        calcu_divi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int res = Integer.parseInt(divi1.getText().toString()) / Integer.parseInt(divi2.getText().toString());
                resultados1.setText(res + " ");
            }
        });
    }
    public void regresar16(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}