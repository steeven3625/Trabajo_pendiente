package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText numero1;
    private EditText numero2;
    private EditText numero3;
    private EditText numero4;
    private TextView Respuesta;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        numero1 = findViewById(R.id.numero1);
        numero2 = findViewById(R.id.numero2);
        numero3 = findViewById(R.id.numero3);
        numero4 = findViewById(R.id.numero4);
        Respuesta = findViewById(R.id.Respuesta);
    }

    public void Suma(View view) {

        try {
            int res = Integer.parseInt(numero1.getText().toString()) + Integer.parseInt(numero2.getText().toString());
            Respuesta.setText(res + " ");
        } catch (Exception e) {
            Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
        }
    }

    public void Resta(View view) {
        try {
            int res = Integer.parseInt(numero1.getText().toString()) - Integer.parseInt(numero2.getText().toString());
            Respuesta.setText(res + " ");
        } catch (Exception e) {
            Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
        }
    }

    public void Multi(View view) {
        try {
            int res = Integer.parseInt(numero1.getText().toString()) * Integer.parseInt(numero2.getText().toString());
            Respuesta.setText(res + " ");
        } catch (Exception e) {
            Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
        }
    }

    public void Divi(View view) {
        try {
            int res = Integer.parseInt(numero1.getText().toString()) / Integer.parseInt(numero2.getText().toString());
            Respuesta.setText(res + " ");
        } catch (Exception e) {
            Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
        }
    }

    public void fibo(View view) {
        try {
            int number = Integer.parseInt(numero3.getText().toString());
            int res = fibonacci(number);
            Respuesta.setText(res + " ");
        } catch (Exception e) {
            Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
        }
    }
    public int fibonacci(int number) {
        if (number == 0 || number == 1) {
            return number;
        } else {
            return fibonacci(number - 1) + fibonacci(number - 2);
        }
    }
    public void recur(View v) {
        if (numero4.getText().length() < 1) {
            Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
        } else {
            int number1 = Integer.parseInt(numero4.getText().toString());
            int res = factorial(number1);
            Respuesta.setText(res + " ");
        }
    }
    public int factorial(int number1){
        if(number1==0 || number1==1){
            return 1;
        }else{
            return number1 * factorial(number1-1);
        }
    }
    public void start(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}