package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class solo_fibo extends AppCompatActivity {
    private EditText fibo1;
    Button calcu_fibo;
    TextView resultados3;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solo_fibo);
        fibo1 = findViewById(R.id.fibo1);
        calcu_fibo = findViewById(R.id.calcu_fibo);
        resultados3 = findViewById(R.id.resultados3);
        calcu_fibo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int number = Integer.parseInt(fibo1.getText().toString());
                int res = fibonacci(number);
                resultados3.setText(res + " ");
            }
            public int fibonacci(int number) {
                if (number == 0 || number == 1) {
                    return number;
                } else {
                    return fibonacci(number - 1) + fibonacci(number - 2);
                }
            }
        });
    }
    public void regresar14(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}