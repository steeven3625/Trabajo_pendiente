package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class factorial1 extends AppCompatActivity {
    TextView res_factorial;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_factorial1);
        res_factorial= findViewById(R.id.res_factorial);
        int resultado =getIntent().getIntExtra("resul",0);

        res_factorial.setText(resultado + " ");
    }
    public void regresar3(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}