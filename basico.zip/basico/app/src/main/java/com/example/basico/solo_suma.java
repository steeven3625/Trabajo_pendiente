package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class solo_suma extends AppCompatActivity {
    private EditText suma1;
    private EditText suma2;
    Button calcu_suma;
    TextView resultados;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solo_suma);
        suma1 = findViewById(R.id.suma1);
        suma2 = findViewById(R.id.suma2);
        calcu_suma = findViewById(R.id.calcu_suma);
        resultados = findViewById(R.id.resultados);
        calcu_suma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int res = Integer.parseInt(suma1.getText().toString()) + Integer.parseInt(suma2.getText().toString());
                resultados.setText(res + " ");
            }
        });
    }
    public void regresar11(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}