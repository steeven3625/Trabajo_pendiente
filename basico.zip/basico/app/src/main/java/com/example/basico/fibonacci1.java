package com.example.basico;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class fibonacci1 extends AppCompatActivity {
    TextView res_fibo;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fibonacci1);
        res_fibo= findViewById(R.id.res_fibo);
        int resultado =getIntent().getIntExtra("resul",0);

        res_fibo.setText(resultado + " ");
    }
    public void regresar2(View view){
        Intent i = new Intent(this, MainActivity2.class);
        startActivity(i);
    }
}